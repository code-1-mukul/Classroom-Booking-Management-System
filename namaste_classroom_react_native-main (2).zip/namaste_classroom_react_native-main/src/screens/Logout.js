import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Logout = () => {
  return (
    <View>
      <Text>Logout</Text>
    </View>
  )
}

export default Logout

const styles = StyleSheet.create({})